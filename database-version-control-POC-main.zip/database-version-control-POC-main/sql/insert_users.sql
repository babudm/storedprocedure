INSERT INTO users (username, email) VALUES ('mariyababu', 'mariyababu@enreap.com');
INSERT INTO users (username, email) VALUES ('avinash', 'avinash@enreap.com');
