INSERT INTO users (username, email) VALUES ('charlie', 'charlie@example.com');
